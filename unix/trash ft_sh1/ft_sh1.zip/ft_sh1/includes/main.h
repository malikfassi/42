/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mfassi-f <mfassi-f@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/21 21:32:17 by mfassi-f          #+#    #+#             */
/*   Updated: 2013/12/25 18:34:23 by mfassi-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MAIN_H
# define MAIN_H

#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <signal.h>

#include <libft.h>
#include <get_line.h>
#include <free_arr.h>
#include <search_path.h>
#include <ft_env.h>
#include <ft_cd.h>

#endif
