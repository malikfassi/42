/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mfassi-f <mfassi-f@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/21 19:31:48 by mfassi-f          #+#    #+#             */
/*   Updated: 2013/12/26 20:57:08 by mfassi-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <main.h>
#include <stdio.h>

void	print_prompt(char **envp)
{
	ft_putstr("\x1B[37m(\x1B[0m");
	ft_putstr("\x1B[36m");
	ft_putstr(*find(envp, "PWD=") + 4);
	ft_putstr("\x1B[0m");
	ft_putstr("\x1B[37m)\x1B[0m");
	ft_putstr("\x1B[31m$>\x1B[0m");
}


char	*get_path(char  **envp, char **cmd)
{
	char	**paths;
	char	*part_path;
	char	*path;

	paths = ft_strsplit(envp[0] + 5, ':');
	part_path = ft_strjoin(search_path(paths, cmd[0]), "/");
	path = ft_strjoin(part_path, cmd[0]);
	ft_strdel(&part_path);
	free_arr(&paths);
	return (path);
}

char	**get_cmd()
{
	char    *line;
	char	**cmd;

	line = get_line();
	if (ft_strlen(line) == 0)
	{
		ft_strdel(&line);
		return (NULL);
	}
	cmd = ft_strsplit(line, ' ');
	ft_strdel(&line);
	return (cmd);
}
int main(int argc, char ** argv, char **envp)
{
	(void)	argv;
	char    **cmd;
	pid_t   pid;
	char	*path;

	while (argc == 1)
	{
		print_prompt(envp);
		cmd = get_cmd();
		if (!cmd)
			continue;
		if (ft_strcmp(cmd[0], "env") == 0)
		{
			ft_env(envp, cmd);
			continue;
		}
		if (ft_strcmp(cmd[0], "cd") == 0)
		{
			ft_cd(cmd, envp);
			continue;
		}
		if (ft_strcmp(cmd[0], "setenv") == 0)
		{
			ft_setenv(cmd, envp);
			continue;
		}
		if (ft_strcmp(cmd[0], "exit") == 0)
		{
			free_arr(&cmd);
			exit(0);
		}
		path = get_path(envp, cmd);
		pid = fork();
		if (pid == 0)
		{
			if (execve(path, cmd, envp) == -1)
			{
				ft_putstr("42sh: command not found: ");
				ft_putendl(cmd[0]);
			}
			ft_strdel(&path);
			free_arr(&cmd);
		}
		if (pid < 0)
			ft_putstr("fork failed\n");
		ft_strdel(&path);
		free_arr(&cmd);
		wait(0);
	}
	return(0);
}
