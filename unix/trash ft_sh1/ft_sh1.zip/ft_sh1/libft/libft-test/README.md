libft-test
==========

To install, copy unit_test/ at the root of your lib, then : "make && ./unit_test"

Created by Maxime Bacoux "mbacoux" / "Nax".

Special Thanks :

- Marc Pastor-Abad "mpastor-", intensive segfault testing.
- Sebastien Puyet "spuyet", pointless testing.
- François Montaro "fmontaro", close collaboration.
- Sebastien Sayada "ssayada", best debug failures ever.
- Nino Wextret "nwextret", intensive shower testing.
