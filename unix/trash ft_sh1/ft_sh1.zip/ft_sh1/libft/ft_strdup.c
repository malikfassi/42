/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   strdup.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mfassi-f <mfassi-f@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/22 19:08:21 by mfassi-f          #+#    #+#             */
/*   Updated: 2013/12/08 19:27:35 by mfassi-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./includes/libft.h"
#include <stdlib.h>

char	*ft_strdup(const char*s1)
{
	char	*cpy;

	cpy = (char*)malloc(sizeof(*cpy) * ft_strlen(s1));
	if (cpy != NULL)
	{
		ft_strcpy(cpy, s1);
	}
	return (cpy);
}
