/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mfassi-f <mfassi-f@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/21 19:31:48 by mfassi-f          #+#    #+#             */
/*   Updated: 2014/01/19 17:09:49 by mfassi-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <main.h>

void	print_prompt(void)
{
	ft_putstr("\x1B[37m(\x1B[0m");
	ft_putstr("\x1B[36m");
	ft_putstr(*find(get_env()->envp, "PWD=") + 4);
	ft_putstr("\x1B[0m");
	ft_putstr("\x1B[37m)\x1B[0m");
	ft_putstr("\x1B[31m$>\x1B[0m");
//	ft_putstr("$>");
}

char	****get_cmd(void)
{
	char	*line;
	char	**cmd_pvir;
	char	**cmd_pipe;
	char 	****cmds;
	int		i;
	int		j;

	i = 0;
	line = get_line();
	if (ft_strlen(line) == 0)
	{
		ft_strdel(&line);
		return (NULL);
	}
	cmd_pvir = ft_strsplit(line, ';');
	cmds = (char ****)malloc(sizeof(char ***) * (len_arr(cmd_pvir) + 1));
	i = 0;
	while (cmd_pvir[i])
	{
		cmd_pipe = ft_strsplit(cmd_pvir[i], '|');
		cmds[i] = (char ***)malloc(sizeof(char **) * (2 * len_arr(cmd_pipe) + 2));
		j = 0;
		while (cmd_pipe[j])
		{
			cmds[i][j] = ft_strsplit(cmd_pipe[j], ' ');
			if (cmd_pipe[j + 1])
				cmds[i][j + 1] = "|";
			j++;
		}
		cmds[i][j] = NULL;
		i++;
	}
	cmds[i] = NULL;
	free_arr(cmd_pipe);
	free_arr(&cmd_pvir);
	ft_strdel(&line);
	return (cmds);
}

void	signal_ctrl_c(int sig)
{
	(void) sig;
	ft_putstr("\b \b\b \b\n");
	print_prompt();
}

void	signal_ctrl_z(int sig)
{
	(void) sig;
	ft_putstr("\b \b\b \b");
}

void	signal_gest(void)
{
	signal(SIGINT, signal_ctrl_c);
	signal(SIGTSTP, signal_ctrl_z);
}

int	main(int argc, char **argv, char **envp)
{
	t_env	*env;

	env = get_env();
	set_envp(env, envp);
	while (argc == 1 && argv)
	{
		print_prompt();
		signal_gest();
		CMDS = get_cmd();
		if (!CMDS) //&& if cmd is empty
			continue ;
		exec_cmds();
	}
	return (0);
}
