/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_pipe.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mfassi-f <mfassi-f@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/18 15:28:09 by mfassi-f          #+#    #+#             */
/*   Updated: 2014/01/19 15:36:55 by mfassi-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <main.h>

void	call_child(int *p, char **cmd)
{
	close(p[0]);
	dup2(p[1], 1);
	close(p[1]);
	exec_func(cmd);
}

void	call_father(int *p, char **cmd)
{
	char	**cmd_path;

	wait(0);
	close(p[1]);
	dup2(p[0], 0);
	close(p[0]);
	exec_func(cmd);
}

int	ft_pipe(char **cmd1, char **cmd2)//malloc
{
	pid_t	pid;
	int		p[2];

	pid = fork();
	if (pid == -1)
	{
		ft_putstr_fd("Fork failed\n", 2);
		return (-1);
	}
	if (pid == 0)
		call_child(p, cmd1);
	else
		call_father(p, cmd2);
	return (0);
}
