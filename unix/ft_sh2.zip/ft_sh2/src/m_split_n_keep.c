/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_op.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mfassi-f <mfassi-f@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/19 17:26:40 by mfassi-f          #+#    #+#             */
/*   Updated: 2014/01/19 18:51:32 by mfassi-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 ** MULTI STRSPLIT N KEEP 
 ==> m_split_n_keep("bonjour | la < be ki", "|<") 
 			= ["bonjour", "|", "la", "<", "be ki"]
 */


#include <stdio.h>

static int  get_nbwords(char const *s, char **c) // ["|", "<", ">", "<<", ">>"]
{
	int nb_words;
	int i;
	int	begin;

	i = 0;
	nb_words = 0;
	begin = 0;
	while (*(s + i))
	{
		if (!ft_strncmp(s + i, c[3], 2) || !ft_strncmp(s + i, c[4], 2))
		{
			nb_words++;
			i += 2;
			begin = 1;
			printf("egale a << ou >>\n");
		}	
		else if (!ft_strncmp(s + i, c[0], 1) || !ft_strncmp(s + i, c[1], 1) 
											|| !ft_strncmp(s + i, c[2], 1))
		{
			nb_words++;
			i++;
			begin = 1;
			printf("egale a | ou < ou >\n");
		}
		else
			begin = 1;
		if (begin)
		{
			printf("debut mot\n");
			while (*(s + i) && (ft_strncmp(s + i, c[3], 2) 
							|| ft_strncmp(s + i, c[4], 2) 
							|| ft_strncmp(s + i, c[0], 1) 
							|| ft_strncmp(s + i, c[1], 1) 
							|| ft_strncmp(s + i, c[2], 1)))
				i++;
		}
		else
			i++;
		begin = 0;
	}
	return (nb_words);
}

int main()
{
	char	*tab[5] = {"|", "<", ">", "<<", ">>"};

	printf("%d", get_nbwords("ceci est une    phrase  longue", tab));
	return (0);
}
