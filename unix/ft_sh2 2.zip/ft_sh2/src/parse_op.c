/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_op.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mfassi-f <mfassi-f@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/19 17:26:40 by mfassi-f          #+#    #+#             */
/*   Updated: 2014/01/21 17:40:29 by mfassi-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 ** MULTI STRSPLIT N KEEP 
 ==> m_split_n_keep("bonjour | la < be ki", "|<") 
 = ["bonjour", "|", "la", "<", "be ki"]
 */

#include <main.h>
#include <libft.h>


static void	check_words(char const *s, char **c, int *i, int *nb_words)
{

	if (nb_words && *(s + *i) && ft_strncmp(s + *i, c[3], 2) 
				&& ft_strncmp(s + *i, c[4], 2) 
				&& ft_strncmp(s + *i, c[0], 1) 
				&& ft_strncmp(s + *i, c[1], 1))
		(*nb_words)++;
	while (*(s + *i) && ft_strncmp(s + *i, c[3], 2) 
				&& ft_strncmp(s + *i, c[4], 2) 
				&& ft_strncmp(s + *i, c[0], 1) 
				&& ft_strncmp(s + *i, c[1], 1) 
				&& ft_strncmp(s + *i, c[2], 1))
		(*i)++;
}

static void	check_op(char const *s, char **c, int *i, int *nb_words)
{
	if (!ft_strncmp(s + *i, c[3], 2) || !ft_strncmp(s + *i, c[4], 2))
	{
		if (nb_words)
			(*nb_words)++;
		(*i) += 2;
	}	
	else if (!ft_strncmp(s + *i, c[0], 1) || !ft_strncmp(s + *i, c[1], 1) 
			|| !ft_strncmp(s + *i, c[2], 1))
	{
		if (nb_words)
			(*nb_words)++;
		(*i)++;
	}
}
static int  get_nbwords(char const *s, char **c)
{
	int nb_words;
	int i;

	i = 0;
	nb_words = 0;
	while (*(s + i))
	{
		check_op(s, c, &i, &nb_words);
		check_words(s, c, &i, &nb_words);
	}
	return (nb_words);
}

char        ***parse_op(char const *s, char **c)
{
	int		start;
	int		end;
	char	***ptr;
	int		i;

	start = 0;
	end = 0;
	i = 0;
	ptr = (char ***)ft_memalloc(sizeof(char **) * (get_nbwords(s, c) + 1));
	while (get_nbwords(s, c) - i)
	{
		start = end;
		check_op(s, c, &end, NULL);
		ptr[i] = ft_strsubsplit(s,' ', start, end - start);
		if (ptr[i])
			i++;
		start = end;
		check_words(s, c, &end, NULL);
		ptr[i] = ft_strsubsplit(s, ' ', start, end - start);
		if (ptr[i])
			i++;
	}
	ptr[i] = NULL;
	return (ptr);
}
