/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   execute_commands.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mfassi-f <mfassi-f@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/18 16:22:21 by mfassi-f          #+#    #+#             */
/*   Updated: 2014/01/21 17:40:33 by mfassi-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <main.h>
#include <stdio.h>

char    *get_path(char **cmd)
{
    char    **paths;
    char    *part_path;
    char    *path;

    paths = ft_strsplit(*find(ENVP,"PATH=") + 5, ':');
    part_path = ft_strjoin(search_path(paths, cmd[0]), "/");
    path = ft_strjoin(part_path, cmd[0]);
    ft_strdel(&part_path);
    free_arr(&paths);
    return (path);
}

int implemented_function(char **cmd)
{
	if (!cmd)
		return (1);
	if (ft_strcmp(cmd[0], "exit") == 0)
	{
		free_arr(&cmd);
		return (-1);
	}
	else if (ft_strcmp(cmd[0], "env") == 0)
		ft_env(cmd);
	else if (ft_strcmp(cmd[0], "cd") == 0)
		ft_cd(cmd);
	else if (ft_strcmp(cmd[0], "setenv") == 0)
		ENVP = ft_setenv(cmd);
	else if (ft_strcmp(cmd[0], "unsetenv") == 0)
		ENVP = ft_unsetenv(cmd);
	else
		return (0);
	return (1);
}

void	non_impl_funct(char **cmd)
{
	pid_t	pid;

	printf("je vais executer\n");
	print_arr(cmd);
	pid = fork();
	if (pid == 0 && execve(get_path(cmd), cmd, ENVP) == -1)//free
	{
		ft_putstr_fd("42sh: command not found: ", 2);
		ft_putendl_fd(cmd[0], 2);
		exit(0);
	}
	if (pid < 0)
		ft_putstr_fd("fork failed\n", 2);
	wait(0);
}

int	exec_func(char **cmd)
{
	int		ret;
	
	ret = implemented_function(cmd);
	if (ret == -1)
		exit(0);//free
	if (ret == 1 && !*CMDS)
		return(-1);
	else if (ret == 1)
		cmd++; //bug
	non_impl_funct(cmd);
	return(0);
}

void	exec_cmds()
{
	char	***cmd;

	while (CMDS && *CMDS)
	{
		cmd = *CMDS;
		CMDS++;
		while (cmd && *cmd)
		{
			printf("begin\n");
			print_arr_triple(cmd);
			printf("end\n");
			if (len_arr_triple(cmd) > 2 && ft_strcmp(*(cmd + 1)[0], "|") == 0)
			{
				ft_pipe(cmd);
				cmd += 3;
			}
			else
			{
				if (exec_func(*cmd))
					break ;
				cmd++;
			}
		}
		if (cmd && *cmd)
			break ;
	}
}
