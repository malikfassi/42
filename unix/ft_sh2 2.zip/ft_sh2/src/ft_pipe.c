/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_pipe.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mfassi-f <mfassi-f@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/18 15:28:09 by mfassi-f          #+#    #+#             */
/*   Updated: 2014/01/21 17:07:58 by mfassi-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <main.h>
#include <stdio.h>
void	call_child(int *p, char **cmd)
{
	close(p[0]);
	dup2(p[1], 1);
	close(p[1]);
	exec_func(cmd);
	exit(0);
}

void	call_father(int *p, char **cmd)
{
	wait(0);
	close(p[1]);
	dup2(p[0], 0);
	close(p[0]);
	exec_func(cmd);
	exit(0);
}

int	ft_pipe(char ***cmd)//malloc
{
	pid_t	pid;
	int		p[2];

	pid = fork();
	if (pid == -1)
	{
		ft_putstr_fd("Fork failed\n", 2);
		return (-1);
	}
	if (pid == 0)
		call_child(p, cmd[0]);
	else
	{
		pid = fork();
		if (pid == 0)
			call_father(p, cmd[2]);
		else
			wait(&pid);
	}
	return (0);
}
