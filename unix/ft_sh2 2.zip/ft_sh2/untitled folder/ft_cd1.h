/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cd1.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mfassi-f <mfassi-f@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/25 18:33:18 by mfassi-f          #+#    #+#             */
/*   Updated: 2013/12/30 16:08:25 by fmarin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_CD_H
# define FT_CD_H

# include <libft.h>
# include <utils.h>
# include <unistd.h>

void ft_cd(char **cmd, char **envp);

#endif
